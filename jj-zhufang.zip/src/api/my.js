import request from '@/utils/request'
// import store from '@/store/index'
export const myInfoAPI = () => {
  return request({
    url: '/user'
    // headers: {
    //   authorization: store.state.token
    // }
  })
}
